"""根据论文第12、13页公开数值进行核对；不伪造原始试验。"""
import csv
from pathlib import Path
rows=[('Swin-Tiny',.281,.617,.182),('ResNet50',.352,.548,.452),('EfficientNet-B3',.423,.382,.512),('YOLOv5s',.582,.251,.587),('MobileNetV3',.647,.181,.634)]
smin=min(r[1] for r in rows);smax=max(r[1] for r in rows);rmin=min(r[2] for r in rows);rmax=max(r[2] for r in rows)
out=[]
for name,s,r,q in rows:
 usual=.5*(s-smin)/(smax-smin)+.5*(r-rmin)/(rmax-rmin)
 literal=.5*(s-0*smin)/(smax-smin)+.5*(r-rmin)/(rmax-rmin)
 out.append(dict(model=name,S_reported=s,R_reported=r,Q_reported=q,Q_recomputed_usual=usual,Q_recomputed_literal_0S=literal,S_less_than_R=s<r))
path=Path(__file__).with_name('论文数值一致性核查.csv')
with path.open('w',encoding='utf-8-sig',newline='') as f:
 w=csv.DictWriter(f,fieldnames=out[0].keys());w.writeheader();w.writerows(out)
for x in out:print(x)
