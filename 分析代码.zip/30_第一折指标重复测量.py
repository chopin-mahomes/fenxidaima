import argparse,ast,csv,hashlib,json,time,io,contextlib,sys
from pathlib import Path
from collections import OrderedDict
from types import SimpleNamespace
sys.path.insert(0,str(Path(__file__).with_name('vendor')))
import numpy as np,torch
from PIL import Image
from torch.utils.data import Dataset,DataLoader
from torchvision.models import efficientnet_b3,swin_t
from torchvision.models.detection import FasterRCNN,fasterrcnn_resnet50_fpn,fasterrcnn_mobilenet_v3_large_320_fpn
from torchvision.models.detection.faster_rcnn import FastRCNNPredictor
from torchvision.ops.feature_pyramid_network import FeaturePyramidNetwork,LastLevelMaxPool
from pycocotools.coco import COCO
from pycocotools.cocoeval import COCOeval
from ultralytics import YOLO
p=argparse.ArgumentParser();p.add_argument('--output',required=True);p.add_argument('--repeats',type=int,default=10);p.add_argument('--models',nargs='+',default=None);p.add_argument('--device',default='cuda:0');args=p.parse_args();out=Path(args.output);out.mkdir(parents=True,exist_ok=False)
specs=[('YOLOv5su',None,None,'fivefold_runs_01/fold1/weights/best.pt'),('FasterRCNN_MobileNetV3','14_MobileNet检测器五折.py','weights/fasterrcnn_mobilenet_v3_large_320_fpn-907ea3f9.pth','mobilenet_frcnn_neu_01/fold1/best.pt'),('FasterRCNN_ResNet50','19_ResNet50检测器五折.py','weights/fasterrcnn_resnet50_fpn_coco-258fb6c6.pth','resnet50_frcnn_neu_01/fold1/best.pt'),('FasterRCNN_EfficientNetB3','22_EfficientNetB3检测器五折.py','weights/efficientnet_b3_rwightman-b3899882.pth','efficientnet_b3_frcnn_neu_01/fold1/best.pt'),('FasterRCNN_SwinTiny','25_SwinTiny检测器五折.py','weights/swin_t-704ceda3.pth','swintiny_frcnn_neu_01/fold1/best.pt')]
if args.models:specs=[s for s in specs if s[0] in args.models]
if not specs:raise ValueError('no recognized models')
listfiles={'clean':Path('splits_neu_5fold/fold1/test.txt'),'noise':Path('mobilenet_robustness_neu_01/fold1_noise_images.txt'),'brightness':Path('mobilenet_robustness_neu_01/fold1_brightness_images.txt')}
for f in listfiles.values():
 if not f.is_file():raise FileNotFoundError(f)
# Restore the same dataset and COCO evaluation logic used by torchvision experiments.
s=Path('19_ResNet50检测器五折.py').read_text(encoding='utf8');tree=ast.parse(s);objs=[ast.get_source_segment(s,n) for n in tree.body if isinstance(n,(ast.ClassDef,ast.FunctionDef)) and n.name in ('NEU','collate','evaluate')];exec('\n\n'.join(objs),globals());a=SimpleNamespace(device=args.device,batch=4,weights=None)
def gt_for(paths):
 gt={'images':[],'annotations':[],'categories':[{'id':i,'name':str(i)} for i in range(1,7)],'info':{}};ann=1
 for i,path in enumerate(paths):
  with Image.open(path) as im:w,h=im.size
  gt['images'].append({'id':i,'height':h,'width':w});lab=path.parent.parent.parent/'labels'/path.parent.name/(path.stem+'.txt')
  for line in lab.read_text(encoding='utf8').splitlines():
   c,x,y,bw,bh=map(float,line.split());gt['annotations'].append({'id':ann,'image_id':i,'category_id':int(c)+1,'bbox':[(x-bw/2)*w,(y-bh/2)*h,bw*w,bh*h],'area':bw*w*bh*h,'iscrowd':0});ann+=1
 with contextlib.redirect_stdout(io.StringIO()):coco=COCO();coco.dataset=gt;coco.createIndex()
 return coco
def yolo_eval(model,paths,coco):
 pred=[]
 for i in range(0,len(paths),16):
  batch=paths[i:i+16];results=model.predict(source=[str(x) for x in batch],imgsz=640,conf=.001,iou=.7,max_det=300,device='0',verbose=False)
  for j,res in enumerate(results):
   for b,c,score in zip(res.boxes.xyxy.cpu().tolist(),res.boxes.cls.cpu().tolist(),res.boxes.conf.cpu().tolist()):
    x1,y1,x2,y2=b;pred.append({'image_id':i+j,'category_id':int(c)+1,'bbox':[x1,y1,x2-x1,y2-y1],'score':float(score)})
 if not pred:return 0.0
 with contextlib.redirect_stdout(io.StringIO()):
  ev=COCOeval(coco,coco.loadRes(pred),'bbox');ev.params.iouThrs=np.array([.5]);ev.evaluate();ev.accumulate();ev.summarize()
 return float(ev.stats[0])
paths={k:[Path(x) for x in f.read_text(encoding='utf8').splitlines() if x.strip()] for k,f in listfiles.items()};gts={k:gt_for(v) for k,v in paths.items()};datasets={k:NEU(v) for k,v in listfiles.items()};rows=[]
meta={'fold':1,'repeats':args.repeats,'device':torch.cuda.get_device_name(0),'models':[],'note':'same fixed trained weights and same fixed images repeated; not independent training or independently sampled perturbations; no CV imputation','created_utc':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime())}
for name,script,weights,checkpoint in specs:
 print('START',name,flush=True);a.weights=weights
 if script is None:model=YOLO(checkpoint)
 else:
  s=Path(script).read_text(encoding='utf8');tree=ast.parse(s);segments=[ast.get_source_segment(s,n) for n in tree.body if isinstance(n,(ast.ClassDef,ast.FunctionDef)) and n.name in ('EfficientNetB3FPN','SwinTinyFPN','build')];exec('\n\n'.join(segments),globals());model=build();model.load_state_dict(torch.load(checkpoint,map_location=args.device,weights_only=True)['model']);model.eval()
 meta['models'].append({'name':name,'checkpoint':str(Path(checkpoint).resolve()),'sha256':hashlib.sha256(Path(checkpoint).read_bytes()).hexdigest()})
 (out/'metadata.json').write_text(json.dumps(meta,ensure_ascii=False,indent=2),encoding='utf8')
 for repeat in range(1,args.repeats+1):
  scores={};start=time.perf_counter()
  for kind in ('clean','noise','brightness'):
   scores[kind]=yolo_eval(model,paths[kind],gts[kind]) if script is None else evaluate(model,datasets[kind])
  if scores['clean']<=0:raise ValueError('clean AP is zero; relative drop undefined')
  drop=((scores['clean']-scores['noise'])+(scores['clean']-scores['brightness']))/(2*scores['clean']);row={'dataset':'NEU-DET','fold':1,'model':name,'repeat':repeat,**scores,'mean_relative_drop':drop,'seconds':time.perf_counter()-start};rows.append(row)
  with (out/'measurements.csv').open('w',encoding='utf-8-sig',newline='') as f:
   w=csv.DictWriter(f,fieldnames=rows[0]);w.writeheader();w.writerows(rows)
  print(name,repeat,'clean',round(scores['clean'],6),'drop',round(drop,6),flush=True)
 del model;torch.cuda.empty_cache()
