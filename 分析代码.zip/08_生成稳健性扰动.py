import argparse,json,hashlib,shutil
from pathlib import Path
import cv2,numpy as np
p=argparse.ArgumentParser();p.add_argument('--list',required=True,help='单折 test.txt');p.add_argument('--output',required=True);p.add_argument('--seed',type=int,default=42);a=p.parse_args();out=Path(a.output).resolve();out.mkdir(parents=True,exist_ok=False)
images=[Path(x) for x in Path(a.list).read_text(encoding='utf-8').splitlines() if x.strip()];rng=np.random.default_rng(a.seed)
classes=['crazing','inclusion','patches','pitted_surface','rolled-in_scale','scratches']
for kind in ['noise','brightness']:
 imdir=out/kind/'images'/'test';labdir=out/kind/'labels'/'test';imdir.mkdir(parents=True);labdir.mkdir(parents=True)
 for i,img in enumerate(images):
  array=cv2.imdecode(np.fromfile(str(img),dtype=np.uint8),cv2.IMREAD_COLOR)
  if array is None:raise ValueError(f'无法读取 {img}')
  if kind=='noise':
   array=np.clip(array.astype(np.float32)/255+rng.normal(0,.1,array.shape),0,1)*255
  else:array=array.astype(np.float32)*.7
  name=f'{i:05d}_{img.stem}';dest=imdir/(name+'.png')
  ok,encoded=cv2.imencode('.png',array.astype(np.uint8))
  if not ok:raise IOError(dest)
  encoded.tofile(str(dest))
  lab=img.parent.parent.parent/'labels'/img.parent.name/(img.stem+'.txt')
  if not lab.is_file():raise FileNotFoundError(lab)
  shutil.copy2(lab,labdir/(name+'.txt'))
 cfg={'path':str(out/kind),'train':str(imdir),'val':str(imdir),'test':str(imdir),'names':dict(enumerate(classes))}
 (out/kind/'data.yaml').write_text(json.dumps(cfg,ensure_ascii=False,indent=2),encoding='utf-8')
 print(kind,len(images))
print('只用于评估；train/val字段为满足格式而设置，禁止用于训练和选模。')
