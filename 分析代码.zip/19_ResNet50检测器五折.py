import argparse,csv,hashlib,json,random,sys,time,contextlib,io
from pathlib import Path
sys.path.insert(0,str(Path(__file__).with_name('vendor')))
import numpy as np,torch
from PIL import Image
from torch.utils.data import Dataset,DataLoader
from torchvision.models.detection import fasterrcnn_resnet50_fpn
from torchvision.models.detection.faster_rcnn import FastRCNNPredictor
from pycocotools.coco import COCO
from pycocotools.cocoeval import COCOeval
p=argparse.ArgumentParser();p.add_argument('--splits',default='splits_neu_5fold');p.add_argument('--weights',required=True);p.add_argument('--output',required=True);p.add_argument('--folds',type=int,nargs='+',default=[1,2,3,4,5]);p.add_argument('--epochs',type=int,default=10);p.add_argument('--batch',type=int,default=4);p.add_argument('--device',default='cuda:0');p.add_argument('--seed',type=int,default=42);a=p.parse_args();out=Path(a.output);out.mkdir(parents=True,exist_ok=False)
random.seed(a.seed);np.random.seed(a.seed);torch.manual_seed(a.seed);torch.cuda.manual_seed_all(a.seed)
info={'arguments':vars(a),'weights_sha256':hashlib.sha256(Path(a.weights).read_bytes()).hexdigest(),'torch':torch.__version__,'device':torch.cuda.get_device_name(0) if torch.cuda.is_available() else 'cpu','task':'new reproduction Faster R-CNN ResNet50 320 FPN with COCO pretrained detector; NEU 6 classes; not original paper model','time_utc':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime())}
(out/'config.json').write_text(json.dumps(info,ensure_ascii=False,indent=2),encoding='utf-8')
class NEU(Dataset):
 def __init__(self,paths):self.images=[Path(x) for x in Path(paths).read_text(encoding='utf8').splitlines() if x.strip()]
 def __len__(self):return len(self.images)
 def __getitem__(self,i):
  path=self.images[i]
  with Image.open(path) as im:arr=np.array(im.convert('RGB'),dtype=np.uint8)
  h,w=arr.shape[:2];image=torch.from_numpy(arr.copy()).permute(2,0,1).float()/255
  label=path.parent.parent.parent/'labels'/path.parent.name/(path.stem+'.txt');boxes=[];classes=[]
  for line in label.read_text(encoding='utf8').splitlines():
   c,x,y,bw,bh=map(float,line.split());boxes.append([(x-bw/2)*w,(y-bh/2)*h,(x+bw/2)*w,(y+bh/2)*h]);classes.append(int(c)+1)
  return image,{'boxes':torch.tensor(boxes,dtype=torch.float32).reshape(-1,4),'labels':torch.tensor(classes,dtype=torch.int64),'image_id':torch.tensor(i)}
def collate(batch):return tuple(zip(*batch))
def build():
 m=fasterrcnn_resnet50_fpn(weights=None,weights_backbone=None,num_classes=91,min_size=320,max_size=640)
 m.load_state_dict(torch.load(a.weights,map_location='cpu',weights_only=True));f=m.roi_heads.box_predictor.cls_score.in_features;m.roi_heads.box_predictor=FastRCNNPredictor(f,7);m.roi_heads.score_thresh=.001;m.roi_heads.detections_per_img=300
 return m.to(a.device)
def evaluate(model,data):
 model.eval();gt={'images':[],'annotations':[],'categories':[{'id':i,'name':str(i)} for i in range(1,7)],'info':{}};pred=[];ann=1
 with torch.inference_mode():
  for images,targets in DataLoader(data,batch_size=a.batch,shuffle=False,num_workers=0,collate_fn=collate):
   outputs=model([x.to(a.device) for x in images])
   for im,t,o in zip(images,targets,outputs):
    idx=int(t['image_id']);gt['images'].append({'id':idx,'height':int(im.shape[1]),'width':int(im.shape[2])})
    for b,c in zip(t['boxes'].tolist(),t['labels'].tolist()):
     x1,y1,x2,y2=b;gt['annotations'].append({'id':ann,'image_id':idx,'category_id':int(c),'bbox':[x1,y1,x2-x1,y2-y1],'area':max(0,(x2-x1)*(y2-y1)),'iscrowd':0});ann+=1
    for b,c,score in zip(o['boxes'].cpu().tolist(),o['labels'].cpu().tolist(),o['scores'].cpu().tolist()):
     x1,y1,x2,y2=b;pred.append({'image_id':idx,'category_id':int(c),'bbox':[x1,y1,x2-x1,y2-y1],'score':float(score)})
 if not pred:return 0.0
 with contextlib.redirect_stdout(io.StringIO()):
  coco=COCO();coco.dataset=gt;coco.createIndex();res=coco.loadRes(pred);ev=COCOeval(coco,res,'bbox');ev.params.iouThrs=np.array([.5]);ev.evaluate();ev.accumulate();ev.summarize()
 return float(ev.stats[0])
if __name__=='__main__':
 for fold in a.folds:
  random.seed(a.seed+fold);np.random.seed(a.seed+fold);torch.manual_seed(a.seed+fold);torch.cuda.manual_seed_all(a.seed+fold)
  d=out/f'fold{fold}';d.mkdir();split=Path(a.splits)/f'fold{fold}';train=NEU(split/'train.txt');val=NEU(split/'val.txt');test=NEU(split/'test.txt');model=build();optim=torch.optim.AdamW([x for x in model.parameters() if x.requires_grad],lr=.0001,weight_decay=.0005);best=-1;history=[]
  loader=DataLoader(train,batch_size=a.batch,shuffle=True,num_workers=0,collate_fn=collate)
  for epoch in range(1,a.epochs+1):
   model.train();losses=[];start=time.time()
   for images,targets in loader:
    ts=[{k:v.to(a.device) for k,v in t.items()} for t in targets];optim.zero_grad(set_to_none=True);loss=sum(model([x.to(a.device) for x in images],ts).values())
    if not torch.isfinite(loss):raise ValueError('nonfinite training loss')
    loss.backward();optim.step();losses.append(float(loss.detach().cpu()))
   valmap=evaluate(model,val);history.append({'epoch':epoch,'train_loss':float(np.mean(losses)),'validation_map50':valmap,'seconds':time.time()-start})
   if valmap>best:best=valmap;torch.save({'model':model.state_dict(),'fold':fold,'epoch':epoch,'val_map50':valmap},d/'best.pt')
   with (d/'history.csv').open('w',encoding='utf-8-sig',newline='') as f:
    w=csv.DictWriter(f,fieldnames=history[0].keys());w.writeheader();w.writerows(history)
   print(f'fold {fold} epoch {epoch}/{a.epochs} loss {history[-1]["train_loss"]:.4f} val_mAP50 {valmap:.4f} time {history[-1]["seconds"]:.1f}',flush=True)
  checkpoint=torch.load(d/'best.pt',map_location=a.device,weights_only=True);model.load_state_dict(checkpoint['model']);score=evaluate(model,test)
  (d/'test_result.json').write_text(json.dumps({'fold':fold,'images':len(test),'map50':score,'best_epoch':checkpoint['epoch'],'note':'single evaluation, not ten repeated measurements'},indent=2),encoding='utf-8');print(f'FINISHED FOLD {fold}: test mAP50 {score:.5f}',flush=True)
