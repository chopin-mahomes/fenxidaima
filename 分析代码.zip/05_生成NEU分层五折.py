import argparse,csv,hashlib,json
from pathlib import Path
from sklearn.model_selection import StratifiedKFold,train_test_split
p=argparse.ArgumentParser();p.add_argument('--data',required=True);p.add_argument('--output',required=True);a=p.parse_args()
root=Path(a.data).resolve();out=Path(a.output).resolve();out.mkdir(parents=True,exist_ok=False)
classes=['crazing','inclusion','patches','pitted_surface','rolled-in_scale','scratches'];images=[];labels=[]; hashes={}
for split in ['train','val','test']:
 for img in sorted((root/'images'/split).iterdir()):
  if img.suffix.lower() not in ['.jpg','.jpeg','.png','.bmp']:continue
  lab=root/'labels'/split/(img.stem+'.txt')
  if not lab.exists():raise FileNotFoundError(lab)
  cls=img.stem.rsplit('_',1)[0]
  if cls not in classes:raise ValueError('unknown class: '+cls)
  sha=hashlib.sha256(img.read_bytes()).hexdigest()
  if sha in hashes:raise ValueError(f'duplicate images: {hashes[sha]} and {img}')
  hashes[sha]=img;images.append(img);labels.append(cls)
with (out/'image_manifest.csv').open('w',newline='',encoding='utf-8-sig') as f:
 w=csv.writer(f);w.writerow(['image','class','sha256']);w.writerows((str(x),y,hashlib.sha256(x.read_bytes()).hexdigest()) for x,y in zip(images,labels))
import numpy as np
images=np.array(images,dtype=object);labels=np.array(labels)
for fold,(tr,te) in enumerate(StratifiedKFold(n_splits=5,shuffle=True,random_state=42).split(images,labels),1):
 tr,va=train_test_split(tr,test_size=.1,random_state=42,stratify=labels[tr]);d=out/f'fold{fold}';d.mkdir()
 for name,idx in [('train',tr),('val',va),('test',te)]:
  (d/(name+'.txt')).write_text('\n'.join(str(images[i]) for i in idx)+'\n',encoding='utf-8')
 cfg={'path':str(d),'train':str(d/'train.txt'),'val':str(d/'val.txt'),'test':str(d/'test.txt'),'names':dict(enumerate(classes))}
 (d/'data.yaml').write_text(json.dumps(cfg,ensure_ascii=False,indent=2),encoding='utf-8')
 print(f'fold {fold}: train={len(tr)} val={len(va)} test={len(te)}')
