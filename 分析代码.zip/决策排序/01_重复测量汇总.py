from common import *
import statistics
args(2,"01_重复测量汇总.py 测量记录.csv 汇总.csv")
rows=read(sys.argv[1]); out=[]
for (dataset,fold,model,metric), group in groups(rows,["dataset","fold","model","metric"]).items():
    vals=[float(r["value"]) for r in group]
    if len(vals)!=10: raise ValueError(f"{dataset}/{fold}/{model}/{metric}: 需要10次，实际{len(vals)}次")
    if len({r["repeat"] for r in group})!=10: raise ValueError("重复编号必须唯一")
    directions={r["direction"] for r in group}
    if len(directions)!=1 or not directions <= {"benefit","cost"}: raise ValueError("方向必须一致且为 benefit 或 cost")
    mean=statistics.mean(vals)
    if mean==0: raise ValueError("均值为零，CV无法计算")
    out.append(dict(dataset=dataset,fold=fold,model=model,metric=metric,direction=directions.pop(),median=statistics.median(vals),cv=statistics.pstdev(vals)/abs(mean)))
write(sys.argv[2],out)
