from common import *
def rank(dist,weights,power=2,gamma=.5):
    ws={(r["dataset"],r["fold"],r["metric"]):float(r["weight"]) for r in weights}; out=[]
    for (ds,fold),block in groups(dist,["dataset","fold"]).items():
        models=groups(block,["model"]); metricsets=[{r["metric"] for r in g} for g in models.values()]
        if any(s!=metricsets[0] for s in metricsets): raise ValueError("模型指标不完整")
        srs=[]
        for (model,),g in models.items():
            xs=[float(r["d_positive"])*ws[(ds,fold,r["metric"])]**power for r in g]
            srs.append((model,sum(xs),max(xs)))
        sl,sh=min(x[1] for x in srs),max(x[1] for x in srs); rl,rh=min(x[2] for x in srs),max(x[2] for x in srs)
        if sh==sl or rh==rl: raise ValueError("S或R归一化分母为零")
        ranked=sorted([(m,s,r,gamma*(s-sl)/(sh-sl)+(1-gamma)*(r-rl)/(rh-rl)) for m,s,r in srs],key=lambda x:x[3])
        for i,(m,s,r,q) in enumerate(ranked): out.append(dict(dataset=ds,fold=fold,model=m,S=s,R=r,Q=q,rank=i+1))
    return out
if __name__=="__main__":
    args(3,"05_VIKOR排序.py 距离.csv 权重.csv 排序.csv"); write(sys.argv[3],rank(read(sys.argv[1]),read(sys.argv[2])))
