from common import *
args(2,"04_理想解与距离.py 模糊矩阵.csv 距离.csv")
rows=read(sys.argv[1]);out=[]
for key,g in groups(rows,["dataset","fold","metric"]).items():
    vals=[tuple(float(r[k]) for k in ("mu","nu","pi")) for r in g]
    ideals=[]
    for mu,nu in [(max(v[0] for v in vals),min(v[1] for v in vals)),(min(v[0] for v in vals),max(v[1] for v in vals))]:
        rem=1-mu*mu-nu*nu
        if rem < -1e-10: raise ValueError(f"{key}: 理想解超出球面")
        ideals.append((mu,nu,math.sqrt(max(0,rem))))
    for r,v in zip(g,vals):
        d=[math.sqrt(sum((a-b)**2 for a,b in zip(v,ideal))) for ideal in ideals]
        out.append(dict(dataset=r["dataset"],fold=r["fold"],model=r["model"],metric=r["metric"],d_positive=d[0],d_negative=d[1]))
write(sys.argv[2],out)
