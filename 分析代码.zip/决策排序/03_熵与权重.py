from common import *
args(2,"03_熵与权重.py 模糊矩阵.csv 权重.csv")
rows=read(sys.argv[1]); out=[]
for (dataset,fold), block in groups(rows,["dataset","fold"]).items():
    es=[]
    for (metric,),g in groups(block,["metric"]).items():
        terms=[]
        for r in g:
            mu,nu,pi=[float(r[k]) for k in ("mu","nu","pi")]; den=max(mu,pi)
            if den==0: raise ValueError(f"{metric}: 熵公式出现0/0，须核对原文或作者的处理")
            terms.append(min(mu,pi)/den*(1-abs(mu-nu)))
        e=sum(terms)/len(terms)/(math.sqrt(2)-1); es.append((metric,e))
    diffs=[1-e for _,e in es]; total=sum(diffs)
    if total<=0 or any(x<0 for x in diffs): raise ValueError(f"{dataset}/{fold}: 原文公式得到负差异度或零分母，需核对公式，禁止自动修正: {es}")
    out.extend(dict(dataset=dataset,fold=fold,metric=metric,entropy=e,weight=(1-e)/total) for metric,e in es)
write(sys.argv[2],out)
