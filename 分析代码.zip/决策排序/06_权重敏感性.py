from common import *
import importlib.util
spec=importlib.util.spec_from_file_location("vikor",Path(__file__).with_name("05_VIKOR排序.py"));mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod)
args(4,"06_权重敏感性.py 距离.csv 权重.csv 情景.csv 排序结果.csv")
dist=read(sys.argv[1]); base=read(sys.argv[2]); scenarios=read(sys.argv[3]);out=[]
for (scenario,),changes in groups(scenarios,["scenario"]).items():
    factors={r["metric"]:float(r["factor"]) for r in changes}
    if len(factors)!=len(changes) or any(x<0 for x in factors.values()): raise ValueError("情景指标重复或系数为负")
    adjusted=[]
    for key,block in groups(base,["dataset","fold"]).items():
        vals=[float(r["weight"])*factors.get(r["metric"],1) for r in block]; total=sum(vals)
        if total<=0: raise ValueError("情景权重之和必须为正")
        adjusted += [dict(r,weight=v/total) for r,v in zip(block,vals)]
    for r in mod.rank(dist,adjusted): out.append(dict(scenario=scenario,**r))
write(sys.argv[4],out)
