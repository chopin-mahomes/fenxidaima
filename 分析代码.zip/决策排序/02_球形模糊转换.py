from common import *
args(2,"02_球形模糊转换.py 汇总.csv 模糊矩阵.csv")
rows=read(sys.argv[1]); out=[]
for key,g in groups(rows,["dataset","fold","metric"]).items():
    vals=[float(r["median"]) for r in g]; lo=min(vals); hi=max(vals)
    if hi==lo: raise ValueError(f"{key}: 所有模型指标相同，归一化分母为零")
    if len({r["model"] for r in g})!=len(g) or len({r["direction"] for r in g})!=1: raise ValueError(f"{key}: 模型重复或方向不一致")
    for r in g:
        x=float(r["median"]); cv=float(r["cv"])
        if cv<0: raise ValueError("CV不能为负")
        mu=(x-lo)/(hi-lo) if r["direction"]=="benefit" else (hi-x)/(hi-lo)
        nu=min(cv/(1+cv),math.sqrt(max(0,1-mu*mu))); pi=math.sqrt(max(0,1-mu*mu-nu*nu))
        out.append(dict(dataset=r["dataset"],fold=r["fold"],model=r["model"],metric=r["metric"],mu=mu,nu=nu,pi=pi))
write(sys.argv[2],out)
