"""Audit 25 NEU model-fold groups, 75 weights, 375 predictions; aggregate without test-based selection."""
import csv,json,hashlib,math,statistics,time
from pathlib import Path
root=Path('NEU_五折三种子完整复现_01');batch=Path('NEU_第3至5折独立重复批次_01/批次状态.json');meta=json.loads(batch.read_text(encoding='utf8'));assert meta['status']=='completed' and len(meta['tasks'])==13
assert all(t['status']=='completed' or t.get('recovery_verification',{}).get('exit_code')==0 for t in meta['tasks'])
models={'YOLOv5su':'neu_yolo','MobileNetV3':'neu_mobile','ResNet50':'neu_resnet','EfficientNetB3':'neu_efficient','SwinTiny':'neu_swin'};ch={2:'第二折',3:'第三折',4:'第四折',5:'第五折'}
def read(p):
 with Path(p).open(encoding='utf-8-sig',newline='') as f:return list(csv.DictReader(f))
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def write(p,rows):
 with p.open('w',encoding='utf-8-sig',newline='') as f:w=csv.DictWriter(f,fieldnames=rows[0]);w.writeheader();w.writerows(rows)
rows=[];counts=[];expected_conditions={'clean','brightness','noise1001','noise1002','noise1003'};list_hashes={}
for fold in range(1,6):
 image_count=360 if fold<=2 else 359
 sets={'clean':Path(f'splits_neu_5fold/fold{fold}/test.txt'),'brightness':Path(f'mobilenet_robustness_neu_01/fold{fold}_brightness_images.txt')}
 for n in (1001,1002,1003):sets[f'noise{n}']=Path(f'neu_noise_perimage_01/fold{fold}_seed{n}/images.txt')
 for kind,file in sets.items():
  assert len([x for x in file.read_text(encoding='utf8').splitlines() if x.strip()])==image_count
  list_hashes[f'{fold}_{kind}']=sha(file)
 for model,prefix in models.items():
  d=Path(f'{prefix}_独立训练重复_01' if fold==1 else f'{prefix}_{ch[fold]}独立训练重复_01');summary=read(d/'三个训练种子汇总.csv');meas=read(d/'固定扰动评估/measurements.csv');m=json.loads((d/'固定扰动评估/metadata.json').read_text(encoding='utf8'))
  assert len(summary)==3 and {int(x['train_seed']) for x in summary}=={42,123,456};assert len(meas)==15 and len({(x['train_seed'],x['condition']) for x in meas})==15
  for kind,file in sets.items():assert m['list_hashes'][kind]==list_hashes[f'{fold}_{kind}'],(model,fold,kind)
  for r in summary:
   seed=int(r['train_seed']);checkpoint=Path(r['checkpoint']);digest=sha(checkpoint);assert digest==r['checkpoint_sha256']==m['weights'][str(seed)]['sha256']
   block=[x for x in meas if int(x['train_seed'])==seed];assert len(block)==5 and {x['condition'] for x in block}==expected_conditions;vals={x['condition']:float(x['map50']) for x in block};assert all(int(x['images'])==image_count for x in block)
   clean=vals['clean'];noise=statistics.mean(vals[f'noise{n}'] for n in (1001,1002,1003));bright=vals['brightness'];assert clean>0;drop=((clean-noise)/clean+(clean-bright)/clean)/2
   for key,val in [('test_clean_map50',clean),('noise_mean_map50',noise),('brightness_map50',bright),('mean_relative_drop',drop)]:assert math.isclose(float(r[key]),val,abs_tol=1e-12),(model,fold,seed,key)
   for x in block:
    file=d/'固定扰动评估'/x['predictions'];pred=json.loads(file.read_text(encoding='utf8'))
    for box in pred:
     assert 0<=int(box['image_id'])<image_count and 1<=int(box['category_id'])<=6 and 0<=float(box['score'])<=1
     assert all(math.isfinite(float(v)) for v in box['bbox']) and float(box['bbox'][2])>=0 and float(box['bbox'][3])>=0
    counts.append(dict(model=model,fold=fold,train_seed=seed,condition=x['condition'],ap50=x['map50'],prediction_boxes=len(pred),prediction_file=str(file.resolve())))
   rows.append(dict(model=model,fold=fold,train_seed=seed,images=image_count,clean_ap50=clean,noise_seed_mean_ap50=noise,brightness_ap50=bright,mean_relative_drop=drop,checkpoint_sha256=digest,checkpoint=str(checkpoint.resolve()),source_summary=str((d/'三个训练种子汇总.csv').resolve())))
  print('AUDITED',model,'fold',fold,flush=True)
assert len(rows)==75 and len(counts)==375;write(root/'逐模型逐折逐训练种子.csv',rows);write(root/'375次预测核验清单.csv',counts)
fold_summ=[];seed_summ=[];overall=[]
for model in models:
 for fold in range(1,6):
  block=[r for r in rows if r['model']==model and r['fold']==fold];assert len(block)==3;entry=dict(model=model,fold=fold,images=block[0]['images'])
  for key in ('clean_ap50','noise_seed_mean_ap50','brightness_ap50','mean_relative_drop'):
   vals=[r[key] for r in block];entry[key+'_mean']=statistics.mean(vals);entry[key+'_sample_sd']=statistics.stdev(vals)
  fold_summ.append(entry)
 for seed in (42,123,456):
  block=[r for r in rows if r['model']==model and r['train_seed']==seed];assert len(block)==5;entry=dict(model=model,train_seed=seed)
  for key in ('clean_ap50','noise_seed_mean_ap50','brightness_ap50','mean_relative_drop'):entry[key+'_five_fold_mean']=statistics.mean(r[key] for r in block)
  seed_summ.append(entry)
 block=[r for r in seed_summ if r['model']==model];entry=dict(model=model,folds=5,train_seeds=3)
 for key in ('clean_ap50','noise_seed_mean_ap50','brightness_ap50','mean_relative_drop'):
  vals=[r[key+'_five_fold_mean'] for r in block];entry[key+'_mean']=statistics.mean(vals);entry[key+'_sd_among_seed_five_fold_means']=statistics.stdev(vals)
 overall.append(entry)
write(root/'逐模型逐折汇总.csv',fold_summ);write(root/'逐模型逐训练种子五折均值.csv',seed_summ);write(root/'五模型五折三种子汇总.csv',overall)
(root/'核验元数据.json').write_text(json.dumps({'created_utc':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),'batch_status_sha256':sha(batch),'list_hashes':list_hashes,'models':5,'folds':5,'weights':75,'predictions':375,'images_per_fold':[360,360,359,359,359],'seed_labels':[42,123,456],'note':'fold AP means are unweighted, not pooled COCO AP; seed variation from five-fold averages is descriptive; test previously inspected'},ensure_ascii=False,indent=2),encoding='utf8')
for r in overall:print('SUMMARY',r['model'],'clean',round(r['clean_ap50_mean'],5),'noise',round(r['noise_seed_mean_ap50_mean'],5),'drop',round(r['mean_relative_drop_mean'],5),flush=True)
print('PASS 25 model-fold groups, 75 weights, 375 predictions, 25 condition list hashes',flush=True)
